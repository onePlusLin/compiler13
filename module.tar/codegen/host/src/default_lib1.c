// tvm target: c -keys=arm_cpu,cpu -mcpu=cortex-m55
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#include <tvm_ethosu_runtime.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t TVMDeviceEthosUActivate(void*);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t TVMDeviceEthosUOpen(void*);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_tvmgen_default_ethos_u_main_0(int8_t*, int8_t*, uint8_t*, void*);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t TVMDeviceEthosUClose(void*);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t TVMDeviceEthosUDeactivate(void*);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_add_clip_cast(uint8_t* p0, int8_t* T_cast, uint8_t* global_workspace_1_var) {
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 409600; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3_inner = 0; ax3_inner < 3; ++ax3_inner) {
      int32_t cse_var_1 = ((ax0_ax1_fused_ax2_fused * 3) + ax3_inner);
      T_cast[cse_var_1] = ((int8_t)(((int32_t)p0[cse_var_1]) - 128));
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(uint8_t* serving_default_input_1_0_buffer_var, int8_t* StatefulPartitionedCall_0_buffer_var, uint8_t* global_workspace_0_var, void* device_context_ethos_u) {
  if (TVMDeviceEthosUActivate(device_context_ethos_u) != 0 ) return -1;
  void* sid_1_let = (&(global_workspace_0_var[6553600]));
  if (tvmgen_default_fused_cast_add_clip_cast(serving_default_input_1_0_buffer_var, sid_1_let, global_workspace_0_var) != 0 ) return -1;
  if (TVMDeviceEthosUOpen(device_context_ethos_u) != 0 ) return -1;
  if (tvmgen_default_tvmgen_default_ethos_u_main_0(sid_1_let, StatefulPartitionedCall_0_buffer_var, global_workspace_0_var, device_context_ethos_u) != 0 ) return -1;
  if (TVMDeviceEthosUClose(device_context_ethos_u) != 0 ) return -1;
  if (TVMDeviceEthosUDeactivate(device_context_ethos_u) != 0 ) return -1;
  return 0;
}

